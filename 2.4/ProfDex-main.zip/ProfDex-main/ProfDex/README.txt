Step 1: Clone the repo

Step 2: Start your mongodb compass

Step 3: Make a new connection

Step 4: Copy the .env connection url to the mongodb setup thing

Step 5: Connect

Step 6: Type "npm start" in the terminal

Step 7: type localhost in your browser 