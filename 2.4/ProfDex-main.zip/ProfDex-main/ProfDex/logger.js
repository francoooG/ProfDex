// logger.js
const fs = require('fs');
const path = require('path');
const { createLogger, format, transports } = require('winston');
const DailyRotateFile = require('winston-daily-rotate-file');

const LOG_DIR = process.env.LOG_DIR || path.join(__dirname, 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const redact = (msg) =>
  typeof msg === 'string'
    ? msg.replace(/(password["']?\s*:\s*["']).*?(["'])/ig, '$1***$2')
         .replace(/(password=)[^&\s]+/ig, '$1***')
    : msg;

const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: format.combine(
    format.timestamp(),
    format.errors({ stack: true }),
    format.printf(info => {
      const { timestamp, level, message, ...rest } = info;

      // redact message (string)
      const safeMsg = redact(message);
      
      // stringify and redact extra fields too
      const metaStr = Object.keys(rest).length ? ' ' + JSON.stringify(rest) : '';
      const safeMetaStr = metaStr ? ' ' + redact(metaStr) : '';

      return `${timestamp} ${level.toUpperCase()} ${safeMsg}${safeMetaStr}`;
    })
  ),
  transports: [
    new transports.Console(),
    new DailyRotateFile({
      dirname: LOG_DIR,
      filename: 'app-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxFiles: '14d',
      zippedArchive: true
    })
  ]
});

module.exports = logger;
