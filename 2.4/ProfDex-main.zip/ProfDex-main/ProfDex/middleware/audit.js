// middleware/audit.js
const logger = require('../logger');
const crypto = require('crypto');


const emailFingerprint = (email) =>
  email
    ? crypto
        .createHmac('sha256', process.env.LOG_SALT || 'change-me')
        .update(String(email).toLowerCase().trim())
        .digest('hex')
        .slice(0, 12)
    : undefined;

exports.logAuthAttempt = (req, { stage, success, reason }) => {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const rawEmail = req.body?.email || req.body?.registerEmail;
  const userAgent = req.headers['user-agent'];
  const uid = req.session?.user?._id;
  const emailHash = emailFingerprint(rawEmail);

  logger.log({
    level: success ? 'info' : 'warn',
    message: `AUTH ${stage} ${success ? 'SUCCESS' : 'FAILURE'}`,
    path: req.originalUrl,
    method: req.method,
    ip,
    userAgent,
    uid,
    reason,
    ...(emailHash && { emailHash }) // no raw email stored
  });
};

exports.logValidationFailure = (req, { area, details }) => {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const uid = req.session?.user?._id || 'anonymous';

  logger.warn('VALIDATION FAIL', {
    area,
    path: req.originalUrl,
    method: req.method,
    ip,
    uid,
    details
  });
};

exports.logAccessDenied = (req, { neededRole }) => {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';
  const uid = req.session?.user?._id || 'anonymous';
  const role = req.session?.user?.userType || 'anonymous';

  logger.warn('ACCESS DENIED', {
    neededRole,
    path: req.originalUrl,
    method: req.method,
    ip,
    uid,
    role
  });
};
