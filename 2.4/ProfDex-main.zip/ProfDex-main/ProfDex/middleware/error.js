// middleware/error.js
const logger = require('../logger');

exports.notFound = (req, res, next) => {
  logger.info('HTTP 404', { path: req.originalUrl, method: req.method });
  res.status(404);
  // Generic, no stack traces
  return res.render(__dirname + '/../views/error.hbs', {
    layout: false,
    error: 'Not Found',
    message: 'The page you requested could not be found.'
  });
};

exports.errorHandler = (err, req, res, next) => {
  // Always log full details internally
  logger.error('HTTP 500', { path: req.originalUrl, method: req.method, stack: err.stack, message: err.message });

  // Never show stack traces to users (2.4.1)
  const status = res.statusCode >= 400 ? res.statusCode : 500;
  res.status(status);
  return res.render(__dirname + '/../views/error.hbs', {
    layout: false,
    error: status === 500 ? 'Server Error' : 'Error',
    message: 'An error occurred. Please try again later.' // generic message (2.4.2)
  });
};
